﻿using Microsoft.Playwright;
using ZGB.Website.TestFramework.Extensions;

namespace ZGB.Website.TestFramework.DataTable;

public class DataTableBaseKeywords<TPageKeywords>
{
    public readonly IPage _page;
    public readonly DataTableBaseLocators Locators;

    public TPageKeywords PageKeywords { get; }

    public DataTableBaseKeywords(IPage page, TPageKeywords pageKeywords)
    {
        _page = page;
        Locators = new DataTableBaseLocators(page);
        PageKeywords = pageKeywords;
    }

    public async Task<TPageKeywords> ChangeSortOrder(string columnName)
    {
        await Locators.ColumnHeader(columnName).ClickAsync();
        await Locators.LoadingCircle.IsNotVisible();
        return PageKeywords;
    }

    public async Task<TPageKeywords> Filter(string filterText)
    {
        await Locators.FilterTextbox.FillAsync(filterText);
        return PageKeywords;
    }

    public async Task<TPageKeywords> SwitchToTablePage(int page)
    {
        await Locators.GoToPageButton(page).ClickAsync();
        return PageKeywords;
    }

    public async Task<TPageKeywords> SwitchToLastPage()
    {
        await Locators.LastPageButton.ClickAsync();
        return PageKeywords;
    }

    public async Task<TPageKeywords> SetTablePageSize(int pageSize)
    {
        await _page.WaitForSelectorAsync(Locators.TablePageSizeDropdownString);
        await Locators.TablePageSizeDropdown.ClickAsync();
        await Locators.TablePageSizeOption(pageSize).ClickAsync();
        return PageKeywords;
    }

    public async Task<bool> IsEditPopupContextMenuVisible(int rowIndex, string column)
    {
        await Locators.TableEntry(rowIndex, column).ClickAsync(new() { Button = MouseButton.Right });
        return await Locators.ContextMenu_Edit.IsVisibleAsync();
    }
}
﻿using Microsoft.Playwright;

namespace ZGB.Website.TestFramework.DataTable;

public class DataTableBaseLocators
{
    private readonly IPage _page;

    public DataTableBaseLocators(IPage page)
    {
        _page = page;
    }

    public ILocator Head => _page.Locator("thead");

    public ILocator FilterTextbox => _page.GetByTestId("filterTextBox");
    public ILocator ColumnHeader(string columnName) => _page.Locator($".{columnName}");

    public ILocator TableEntry(int rowIndex, string className) => _page.Locator($"tbody tr:nth-child({rowIndex}) td:nth-child({GetColumnIndex(className).Result})");

    private async Task<int> GetColumnIndex(string className)
    {
        var headers = await _page.QuerySelectorAllAsync("#dataGrid > div.rz-data-grid-data > table > thead > tr > th." + className);
        if (!headers.Any())
        {
            throw new Exception($"Header with class '{className}' not found in dataGrid.");
        }

        var columnIndex = await headers[0].EvaluateAsync<int>("self => Array.from(self.parentElement.children).indexOf(self)");
        return columnIndex + 1;
    }

    public ILocator LoadingCircle => _page.Locator("#dataGrid > div.rz-data-grid-data > div.rz-datatable-loading-content > i");

    public ILocator GoToPageButton(int page) => _page.GetByLabel($"Go to page {page}.");
    public ILocator LastPageButton => _page.GetByLabel("Go to last page");
    public string TablePageSizeDropdownString = ".rz-dropdown-trigger-icon";
    public ILocator TablePageSizeDropdown => _page.Locator(TablePageSizeDropdownString);
    public ILocator TablePageSizeOption(int pageSize) => _page.Locator($"li[aria-label='{pageSize}']");

    public ILocator ContextMenu_Edit => _page.GetByText("editEdit");
    public ILocator EditPopup_Title => _page.Locator("b");
}

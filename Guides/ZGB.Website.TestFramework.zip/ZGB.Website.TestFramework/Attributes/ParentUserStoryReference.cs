﻿namespace ZGB.Website.TestFramework.Attributes
{
    [AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = true)]
    public class ParentUserStoryReference : Attribute
    {
        public int Id { get; }

        public ParentUserStoryReference(int id)
        {
            Id = id;
        }
    }
}

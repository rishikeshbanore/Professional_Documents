﻿namespace ZGB.Website.TestFramework.Attributes
{
    [AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = true)]
    public class TestPlanReference : Attribute
    {
        public int Id { get; }

        public TestPlanReference(int id)
        {
            Id = id;
        }
    }
}

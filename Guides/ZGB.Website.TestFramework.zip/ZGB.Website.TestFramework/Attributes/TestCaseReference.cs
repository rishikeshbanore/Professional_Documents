﻿namespace ZGB.Website.TestFramework.Attributes
{
    [AttributeUsage(AttributeTargets.Method, Inherited = false, AllowMultiple = true)]
    public class TestCaseReference : Attribute
    {
        public int Id { get; }

        public TestCaseReference(int id)
        {
            Id = id;
        }
    }
}

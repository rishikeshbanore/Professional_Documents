﻿namespace ZGB.Website.TestFramework.Attributes
{
    [AttributeUsage(AttributeTargets.Class, Inherited = false, AllowMultiple = true)]
    public class TestSuiteReference : Attribute
    {
        public int Id { get; }

        public TestSuiteReference(int id)
        {
            Id = id;
        }
    }
}

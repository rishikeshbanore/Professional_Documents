﻿using Microsoft.Playwright;

namespace ZGB.Website.TestFramework.Extensions;

public static class IPageExtensions
{
    public static async Task WaitForNetworkIdleAfterNetworkTraffic(this IPage page)
    {
        // Wait for Load to Start
        // there is a change we miss all network traffic => Ignore Exceptions after Timeout
        // We need this call, because we might be too fast and the Loading Operation has not started yet.
        try { await page.WaitForLoadStateAsync(LoadState.Load); } catch (Exception) { /* Ignore */}

        await page.WaitForLoadStateAsync(LoadState.NetworkIdle);
    }
}
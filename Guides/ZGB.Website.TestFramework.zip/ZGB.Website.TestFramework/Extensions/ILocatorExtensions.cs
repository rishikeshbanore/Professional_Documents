﻿using Microsoft.Playwright;

namespace ZGB.Website.TestFramework.Extensions;

public static class ILocatorExtensions
{
    public static async Task ContainsText(this ILocator locator, string? text)
    {
        await Assertions.Expect(locator).ToContainTextAsync(text ?? "",
            new LocatorAssertionsToContainTextOptions { IgnoreCase = true, Timeout = 60000 });
    }
        
    public static async Task HasText(this ILocator locator, string? text)
    {
        await Assertions.Expect(locator).ToHaveTextAsync(text ?? "",
            new LocatorAssertionsToHaveTextOptions { IgnoreCase = true });
    }

    public static async Task DoesNotContainText(this ILocator locator, string text)
    {
        await Assertions.Expect(locator).Not.ToContainTextAsync(text,
            new LocatorAssertionsToContainTextOptions { IgnoreCase = true });
    }

    public static async Task IsVisible(this ILocator locator)
    {
        await Assertions.Expect(locator).ToBeVisibleAsync();
    }

    public static async Task IsNotVisible(this ILocator locator)
    {
        await Assertions.Expect(locator).Not.ToBeVisibleAsync();
    }

    public static async Task WaitForNotVisibleAfterVisible(this ILocator locator)
    {
        // Wait for Visibility
        // there is a change we miss it being visible => Ignore Exceptions
        // We need this call, because we might be too fast and the Operation has not started yet.
        try { await locator.IsVisible(); } catch (Exception) { /* Ignore */}
        await locator.IsNotVisible();
    }

    public static async Task IsHighlighted(this ILocator locator)
    {
        await Assertions.Expect(locator).ToHaveClassAsync("rz-pager-page rz-pager-element rz-state-active rz-state-focused");
    }
}
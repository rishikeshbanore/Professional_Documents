﻿using Microsoft.Playwright;
using ZGB.Tests.Common.Authentication;
using ZGB.Website.TestFramework.Models;

namespace ZGB.Website.TestFramework.Pages.HomePage;

public class HomePageKeywords : BasePageKeywords
{
    private readonly IPage _page;

    public HomePageKeywords(IPage page, Credentials credentials) : base(page, credentials)
    {
        _page = page;
    }

    public ILocator PageHeader => _page.GetByRole(AriaRole.Heading);

    public override async Task WaitUntilPageIsFullyLoaded()
    {
        await PageHeader.IsVisibleAsync();
    }
}
﻿using Microsoft.Playwright;

namespace ZGB.Website.TestFramework.Pages;

public class BasePageLocators
{
    private readonly IPage _page;

    public BasePageLocators(IPage page)
    {
        _page = page;
    }

    public ILocator InformationPopup => _page.Locator(".rz-notification-item");
    public ILocator SideMenu => _page.GetByRole(AriaRole.Link, new() { Name = "home Home" });
    public ILocator SideMenuList => _page.GetByRole(AriaRole.List);

    public ILocator DeliveryBasePayoutConfigurationPageLink()
    {
        return _page.Locator("#DeliveryBasePayoutConfiguration");
    }

    public ILocator GsaOrdersPageLink()
    {
        return _page.Locator("#GsaOrders");
    }

    public ILocator PacCorrectionPageLink()
    {
        return _page.Locator("#PacCorrection");
    }

}
﻿using Microsoft.Playwright;
using ZGB.Tests.Common.Authentication;
using ZGB.Website.TestFramework.DataTable;
using ZGB.Website.TestFramework.Extensions;
using ZGB.Website.TestFramework.Pages.DeliveryBasePayoutConfigurationPage;
using ZGB.Website.TestFramework.Pages.GsaOrdersPage;
using ZGB.Website.TestFramework.Pages.PacCorrectionPage;

namespace ZGB.Website.TestFramework.Pages;

public abstract class BasePageKeywords
{
    internal readonly IPage Page;
    internal readonly Credentials Credentials;
    public readonly BasePageLocators BaseLocators;
    public readonly DataTableBaseLocators DataTableBaseLocators;

    protected BasePageKeywords(IPage page, Credentials credentials)
    {
        Page = page;
        Credentials = credentials;
        BaseLocators = new BasePageLocators(page);
        DataTableBaseLocators = new DataTableBaseLocators(page);
    }

    public async Task<BasePageKeywords> GoToUrl(string url)
    {
        await Page.GotoAsync(url);
        return this;
    }

    public abstract Task WaitUntilPageIsFullyLoaded();

    public async Task ReloadPage()
    {
        await Page.ReloadAsync();
    }

    public async Task<DeliveryBasePayoutConfigurationPageKeywords> GoToDeliveryBasePayoutConfigurationPage()
    {
        await BaseLocators.DeliveryBasePayoutConfigurationPageLink().ClickAsync(new LocatorClickOptions { Timeout = 30000 });
        var pageKeywords = new DeliveryBasePayoutConfigurationPageKeywords(Page, Credentials);
        await pageKeywords.WaitUntilPageIsFullyLoaded();
        if (IsAuthenticationPopupOpen())
        {
            await Login();
        }
        return pageKeywords;
    }


    public async Task<GsaOrdersPageKeywords> GoToGsaOrdersPage()
    {
        await BaseLocators.GsaOrdersPageLink().ClickAsync(new LocatorClickOptions { Timeout = 30000 });
        var pageKeywords = new GsaOrdersPageKeywords(Page, Credentials);
        await pageKeywords.WaitUntilPageIsFullyLoaded();
        if (IsAuthenticationPopupOpen())
        {
            await Login();
        }
        return pageKeywords;
    }

    public async Task<PacCorrectionPageKeywords> GoToPacCorrectionPage()
    {
        await BaseLocators.PacCorrectionPageLink().ClickAsync(new LocatorClickOptions { Timeout = 30000 });
        var pageKeywords = new PacCorrectionPageKeywords(Page, Credentials);
        await pageKeywords.WaitUntilPageIsFullyLoaded();
        if (IsAuthenticationPopupOpen())
        {
            await Login();
        }
        return pageKeywords;
    }

    private bool IsAuthenticationPopupOpen()
    {
        return Page.Context.Pages.Count > 1;
    }


    private async Task Login()
    {
        var popup = Page.Context.Pages[1];

        await popup.FillAsync("input[name='loginfmt']", Credentials.Email);
        await popup.ClickAsync("input[type='submit']");

        await popup.WaitForNetworkIdleAfterNetworkTraffic();

        await popup.WaitForSelectorAsync("input[name='passwd']");
        await popup.FillAsync("input[name='passwd']", Credentials.Password);
        await popup.ClickAsync("input[type='submit']");

        await DataTableBaseLocators.LoadingCircle.WaitForNotVisibleAfterVisible();
    }
}
﻿using Microsoft.Playwright;
using ZGB.Website.TestFramework.DataTable;

namespace ZGB.Website.TestFramework.Pages.GsaOrdersPage;

public class GsaOrdersDataTableKeywords : DataTableBaseKeywords<GsaOrdersPageKeywords>
{
    public GsaOrdersDataTableKeywords(IPage page, GsaOrdersPageKeywords pageKeywords) : base(page, pageKeywords)
    {
    }

    public async Task<GsaOrdersEditPopupKeywords> OpenEditPopupForRow(int rowIndex, string column)
    {
        await Locators.TableEntry(rowIndex, column).ClickAsync(new() { Button = MouseButton.Right });
        await Locators.ContextMenu_Edit.ClickAsync();

        return new GsaOrdersEditPopupKeywords(_page, PageKeywords);
    }
}
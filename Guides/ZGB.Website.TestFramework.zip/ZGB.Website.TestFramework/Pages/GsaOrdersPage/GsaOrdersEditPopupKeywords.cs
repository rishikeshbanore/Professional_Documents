﻿using Microsoft.Playwright;
using ZGB.Website.TestFramework.Models;

namespace ZGB.Website.TestFramework.Pages.GsaOrdersPage;

public class GsaOrdersEditPopupKeywords
{
    public readonly GsaOrdersEditPopupLocators Locators;
    private readonly GsaOrdersPageKeywords _pageKeywords;

    public GsaOrdersEditPopupKeywords(IPage page, GsaOrdersPageKeywords pageKeywords)
    {
        Locators = new GsaOrdersEditPopupLocators(page);
        _pageKeywords = pageKeywords;
    }

    public async Task<GsaOrdersEditPopupKeywords> SetValues(Denomination denomination)
    {
        if (denomination.G500 != null)
        {
            await Locators.G500Input.ClearAsync();
            await Locators.G500Input.FillAsync(denomination.G500.ToString()!);
        }
        if (denomination.G200 != null)
        {
            await Locators.G200Input.ClearAsync();
            await Locators.G200Input.FillAsync(denomination.G200.ToString()!);
        }
        if (denomination.G100 != null)
        {
            await Locators.G100Input.ClearAsync();
            await Locators.G100Input.FillAsync(denomination.G100.ToString()!);
        }
        if (denomination.G50 != null)
        {
            await Locators.G50Input.ClearAsync();
            await Locators.G50Input.FillAsync(denomination.G50.ToString()!);
        }
        if (denomination.G20 != null)
        {
            await Locators.G20Input.ClearAsync();
            await Locators.G20Input.FillAsync(denomination.G20.ToString()!);
        }
        if (denomination.G10 != null)
        {
            await Locators.G10Input.ClearAsync();
            await Locators.G10Input.FillAsync(denomination.G10.ToString()!);
        }
        if (denomination.G5 != null)
        {
            await Locators.G5Input.ClearAsync();
            await Locators.G5Input.FillAsync(denomination.G5.ToString()!);
        }
        if (denomination.G2 != null)
        {
            await Locators.G2Input.ClearAsync();
            await Locators.G2Input.FillAsync(denomination.G2.ToString()!);
        }
        if (denomination.G1 != null)
        {
            await Locators.G1Input.ClearAsync();
            await Locators.G1Input.FillAsync(denomination.G1.ToString()!);
        }
        if (denomination.G050 != null)
        {
            await Locators.G050Input.ClearAsync();
            await Locators.G050Input.FillAsync(denomination.G050.ToString()!);
        }
        if (denomination.G020 != null)
        {
            await Locators.G020Input.ClearAsync();
            await Locators.G020Input.FillAsync(denomination.G020.ToString()!);
        }
        if (denomination.G010 != null)
        {
            await Locators.G010Input.ClearAsync();
            await Locators.G010Input.FillAsync(denomination.G010.ToString()!);
        }
        if (denomination.G005 != null)
        {
            await Locators.G005Input.ClearAsync();
            await Locators.G005Input.FillAsync(denomination.G005.ToString()!);
        }
        if (denomination.G002 != null)
        {
            await Locators.G002Input.ClearAsync();
            await Locators.G002Input.FillAsync(denomination.G002.ToString()!);
        }
        if (denomination.G001 != null)
        {
            await Locators.G001Input.ClearAsync();
            await Locators.G001Input.FillAsync(denomination.G001.ToString()!);
        }

        return this;
    }

    public async Task<GsaOrdersPageKeywords> Cancel()
    {
        await Locators.CancelButton.ClickAsync();
        await _pageKeywords.WaitUntilPageIsFullyLoaded();
        return _pageKeywords;
    }

    public async Task<GsaOrdersPageKeywords> Save()
    {
        await Locators.SaveButton.ClickAsync();
        return _pageKeywords;
    }
    
    public async Task<GsaOrdersEditPopupKeywords> FocusSave()
    {
        await Locators.SaveButton.FocusAsync();
        return this;
    }
}

﻿using Microsoft.Playwright;

namespace ZGB.Website.TestFramework.Pages.GsaOrdersPage;

public class GsaOrdersEditPopupLocators
{
    private readonly IPage _page;

    public GsaOrdersEditPopupLocators(IPage page)
    {
        _page = page;
    }

    public ILocator G500Input => _page.Locator("#g500");
    public ILocator G200Input => _page.Locator("#g200");
    public ILocator G100Input => _page.Locator("#g100");
    public ILocator G50Input => _page.Locator("#g50");
    public ILocator G20Input => _page.Locator("#g20");
    public ILocator G10Input => _page.Locator("#g10");
    public ILocator G5Input => _page.Locator("#g5");
    public ILocator G2Input => _page.Locator("#g2");
    public ILocator G1Input => _page.Locator("#g1");
    public ILocator G050Input => _page.Locator("#g050");
    public ILocator G020Input => _page.Locator("#g020");
    public ILocator G010Input => _page.Locator("#g010");
    public ILocator G005Input => _page.Locator("#g005");
    public ILocator G002Input => _page.Locator("#g002");
    public ILocator G001Input => _page.Locator("#g001");

    public ILocator CancelButton => _page.Locator("#cancel");
    public ILocator SaveButton => _page.Locator("#save");

    public ILocator Sum => _page.Locator("#sum");
}
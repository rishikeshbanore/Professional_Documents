﻿using Microsoft.Playwright;

namespace ZGB.Website.TestFramework.Pages.GsaOrdersPage;
public class GsaOrdersPageLocators
{
    private readonly IPage _page;

    public GsaOrdersPageLocators(IPage page)
    {
        _page = page;
    }

    public ILocator PageHeader => _page.GetByRole(AriaRole.Heading);

    public ILocator DataGrid => _page.Locator("#dataGrid");
}

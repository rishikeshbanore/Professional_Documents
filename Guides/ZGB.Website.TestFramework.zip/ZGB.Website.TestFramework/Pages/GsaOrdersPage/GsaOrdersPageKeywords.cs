﻿using Microsoft.Playwright;
using ZGB.Tests.Common.Authentication;
using ZGB.Website.TestFramework.Extensions;

namespace ZGB.Website.TestFramework.Pages.GsaOrdersPage;

public class GsaOrdersPageKeywords : BasePageKeywords
{
    public readonly GsaOrdersPageLocators Locators;
    public GsaOrdersDataTableKeywords Table { get; set; }

    public GsaOrdersPageKeywords(IPage page, Credentials credentials) : base(page, credentials)
    {
        Locators = new GsaOrdersPageLocators(page);
        Table = new GsaOrdersDataTableKeywords(page, this);
    }

    public override async Task WaitUntilPageIsFullyLoaded()
    {
        await DataTableBaseLocators.LoadingCircle.IsNotVisible();
    }
}
﻿using Microsoft.Playwright;
using ZGB.Website.TestFramework.DataTable;

namespace ZGB.Website.TestFramework.Pages.PacCorrectionPage;

public class PacCorrectionDataTableKeywords : DataTableBaseKeywords<PacCorrectionPageKeywords>
{
    public PacCorrectionDataTableKeywords(IPage page, PacCorrectionPageKeywords pageKeywords) : base(page, pageKeywords)
    {
    }

    public async Task<PacCorrectionEditPopupKeywords> OpenEditPopupForRow(int rowIndex, string column)
    {
        await Locators.TableEntry(rowIndex, column).ClickAsync(new() { Button = MouseButton.Right });
        await Locators.ContextMenu_Edit.ClickAsync();

        return new PacCorrectionEditPopupKeywords(_page, PageKeywords, PageKeywords.Credentials);
    }
}

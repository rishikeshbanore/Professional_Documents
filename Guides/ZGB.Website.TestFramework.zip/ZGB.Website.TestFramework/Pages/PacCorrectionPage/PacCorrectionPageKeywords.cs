﻿using Microsoft.Playwright;
using ZGB.Tests.Common.Authentication;
using ZGB.Website.TestFramework.Extensions;
using ZGB.Website.TestFramework.Models;

namespace ZGB.Website.TestFramework.Pages.PacCorrectionPage;

public class PacCorrectionPageKeywords : BasePageKeywords
{
    public PacCorrectionPageLocators Locators { get; set; }
    public PacCorrectionDataTableKeywords Table { get; set; }

    public PacCorrectionPageKeywords(IPage page, Credentials credentials) : base(page, credentials)
    {
        Locators = new PacCorrectionPageLocators(page);
        Table = new PacCorrectionDataTableKeywords(page, this);
    }

    public override async Task WaitUntilPageIsFullyLoaded()
    {
        await DataTableBaseLocators.LoadingCircle.IsNotVisible();
    }

    public new async Task<PacCorrectionPageKeywords> ReloadPage()
    {
        await Page.ReloadAsync();
        return this;
    }

}

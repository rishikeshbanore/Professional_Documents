﻿using Microsoft.Playwright;

namespace ZGB.Website.TestFramework.Pages.PacCorrectionPage;

public class PacCorrectionEditPopupLocators
{
    private readonly IPage _page;

    public PacCorrectionEditPopupLocators(IPage page)
    {
        _page = page;
    }

    public ILocator PacInput => _page.Locator("#postalAddressCode");
    
    public ILocator CancelButton => _page.Locator("#cancel");
    public ILocator SaveButton => _page.Locator("#save");
    public ILocator AddressLine1 => _page.Locator("#addressLine1");
    public ILocator AddressLine2 => _page.Locator("#addressLine2");
    public ILocator AddressLine3 => _page.Locator("#addressLine3");
    public ILocator AddressLine4 => _page.Locator("#addressLine4");
    public ILocator AddressLine5 => _page.Locator("#addressLine5");
}
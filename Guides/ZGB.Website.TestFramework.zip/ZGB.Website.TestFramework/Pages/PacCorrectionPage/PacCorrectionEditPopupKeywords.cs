﻿using Microsoft.Playwright;
using ZGB.Tests.Common.Authentication;

namespace ZGB.Website.TestFramework.Pages.PacCorrectionPage;

public class PacCorrectionEditPopupKeywords
{
    public readonly PacCorrectionEditPopupLocators Locators;
    public readonly PacCorrectionPageKeywords PageKeywords;

    public PacCorrectionEditPopupKeywords(IPage page, PacCorrectionPageKeywords pageKeywords, Credentials credentials)
    {
        Locators = new PacCorrectionEditPopupLocators(page);
        PageKeywords = pageKeywords;
    }

    public async Task<PacCorrectionEditPopupKeywords> SetValues(string pac)
    {
        await Locators.PacInput.ClearAsync();
        await Locators.PacInput.FillAsync(pac);

        return this;
    }

    public async Task<PacCorrectionPageKeywords> Cancel()
    {
        await Locators.CancelButton.ClickAsync();
        await PageKeywords.WaitUntilPageIsFullyLoaded();
        return PageKeywords;
    }

    public async Task<PacCorrectionPageKeywords> Save(string text = "Operation Is Successful")
    {
        await Locators.SaveButton.ClickAsync();
        return PageKeywords;
    }
}
﻿using Microsoft.Playwright;

namespace ZGB.Website.TestFramework.Pages.PacCorrectionPage;
public class PacCorrectionPageLocators : BasePageLocators
{
    protected readonly IPage _page;

    public PacCorrectionPageLocators(IPage page) : base(page)
    {
        _page = page;
    }

    public ILocator PageHeader => _page.GetByRole(AriaRole.Heading);

    public ILocator DataGrid => _page.Locator("#dataGrid");
}

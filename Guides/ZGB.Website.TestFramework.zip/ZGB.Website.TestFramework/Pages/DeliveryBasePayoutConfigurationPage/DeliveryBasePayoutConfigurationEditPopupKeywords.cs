﻿using Microsoft.Playwright;
using ZGB.Website.TestFramework.Models;

namespace ZGB.Website.TestFramework.Pages.DeliveryBasePayoutConfigurationPage;

public class DeliveryBasePayoutConfigurationEditPopupKeywords
{
    public readonly DeliveryBasePayoutConfigurationEditPopupLocators Locators;
    private readonly DeliveryBasePayoutConfigurationPageKeywords _pageKeywords;

    public DeliveryBasePayoutConfigurationEditPopupKeywords(IPage page
        , DeliveryBasePayoutConfigurationPageKeywords pageKeywords)
    {
        Locators = new DeliveryBasePayoutConfigurationEditPopupLocators(page);
        _pageKeywords = pageKeywords;
    }

    public async Task<DeliveryBasePayoutConfigurationEditPopupKeywords> SetValues(PayoutConfiguration payoutConfiguration)
    {
        if (payoutConfiguration.pensionPayoutPcsDate.HasValue)
        {
            await Locators.PensionPayoutPcsDateField.ClearAsync();
            await Locators.PensionPayoutPcsDateField.FillAsync(payoutConfiguration.pensionPayoutPcsDate.Value.ToString("dd.MM.yyyy"));
        }
        if (payoutConfiguration.pensionPayoutABehaelter.HasValue)
        {
            await Locators.PensionPayoutABehaelterField.ClearAsync();
            await Locators.PensionPayoutABehaelterField.FillAsync(payoutConfiguration.pensionPayoutABehaelter.Value.ToString("dd.MM.yyyy"));
        }
        if (payoutConfiguration.amsPayoutPcs.HasValue)
        {
            await Locators.AmsPayoutPcsField.ClearAsync();
            await Locators.AmsPayoutPcsField.FillAsync(payoutConfiguration.amsPayoutPcs.Value.ToString("dd.MM.yyyy"));
        }
        if (payoutConfiguration.amsPayoutABehaelter.HasValue)
        {
            await Locators.AmsPayoutABehaelterField.ClearAsync();
            await Locators.AmsPayoutABehaelterField.FillAsync(payoutConfiguration.amsPayoutABehaelter.Value.ToString("dd.MM.yyyy"));
        }

        return this;
    }

    public async Task<DeliveryBasePayoutConfigurationPageKeywords> Cancel()
    {
        await Locators.CancelButton.ClickAsync();
        await _pageKeywords.WaitUntilPageIsFullyLoaded();
        return _pageKeywords;
    }

    public async Task<DeliveryBasePayoutConfigurationPageKeywords> Save()
    {
        await Locators.SaveButton.ClickAsync();
        return _pageKeywords;
    }
}
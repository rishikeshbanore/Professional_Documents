﻿using Microsoft.Playwright;
using ZGB.Website.TestFramework.DataTable;

namespace ZGB.Website.TestFramework.Pages.DeliveryBasePayoutConfigurationPage;

public class DeliveryBasePayoutConfigurationDataTableKeywords : DataTableBaseKeywords<DeliveryBasePayoutConfigurationPageKeywords>
{
    public DeliveryBasePayoutConfigurationDataTableKeywords(IPage page, DeliveryBasePayoutConfigurationPageKeywords pageKeywords) : base(page, pageKeywords)
    {
    }

    public async Task<DeliveryBasePayoutConfigurationEditPopupKeywords> OpenEditPopupForRow(int rowIndex, string column)
    {
        await Locators.TableEntry(rowIndex, column).ClickAsync(new() { Button = MouseButton.Right , Timeout = 61000});
        await Locators.ContextMenu_Edit.ClickAsync();

        return new DeliveryBasePayoutConfigurationEditPopupKeywords(_page, PageKeywords);
    }
}

﻿using Microsoft.Playwright;

namespace ZGB.Website.TestFramework.Pages.DeliveryBasePayoutConfigurationPage;
public class DeliveryBasePayoutConfigurationPageLocators
{
    protected readonly IPage _page;

    public DeliveryBasePayoutConfigurationPageLocators(IPage page)
    {
        _page = page;
    }

    public ILocator PageHeader => _page.GetByRole(AriaRole.Heading);

    public ILocator DataGrid => _page.Locator("#dataGrid");

}

﻿using Microsoft.Playwright;

namespace ZGB.Website.TestFramework.Pages.DeliveryBasePayoutConfigurationPage;

public class DeliveryBasePayoutConfigurationEditPopupLocators
{
    private readonly IPage _page;

    public DeliveryBasePayoutConfigurationEditPopupLocators(IPage page)
    {
        _page = page;
    }

    public ILocator PensionPayoutPcsDateField => _page.Locator("#payoutPensionViaCashRecyclerFromDate");
    public ILocator PensionPayoutABehaelterField => _page.Locator("#payoutPensionViaValueTransportFromDate");
    public ILocator AmsPayoutPcsField => _page.Locator("#payoutUnemploymentViaCashRecyclerFromDate");
    public ILocator AmsPayoutABehaelterField => _page.Locator("#payoutUnemploymentViaValueTransportFromDate");

    public ILocator CancelButton => _page.Locator("#cancel");
    public ILocator SaveButton => _page.Locator("#save");
}
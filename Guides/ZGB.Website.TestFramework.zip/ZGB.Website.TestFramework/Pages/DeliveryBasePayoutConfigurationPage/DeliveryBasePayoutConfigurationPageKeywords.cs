﻿using Microsoft.Playwright;
using ZGB.Tests.Common.Authentication;
using ZGB.Website.TestFramework.Extensions;

namespace ZGB.Website.TestFramework.Pages.DeliveryBasePayoutConfigurationPage;

public class DeliveryBasePayoutConfigurationPageKeywords : BasePageKeywords
{
    public DeliveryBasePayoutConfigurationPageLocators Locators { get; set; }
    public DeliveryBasePayoutConfigurationDataTableKeywords Table { get; set; }

    public DeliveryBasePayoutConfigurationPageKeywords(IPage page, Credentials credentials) : base(page, credentials)
    {
        Locators = new DeliveryBasePayoutConfigurationPageLocators(page);
        Table = new DeliveryBasePayoutConfigurationDataTableKeywords(page, this);
    }

    public override async Task WaitUntilPageIsFullyLoaded()
    {
        await DataTableBaseLocators.LoadingCircle.IsNotVisible();
    }
}
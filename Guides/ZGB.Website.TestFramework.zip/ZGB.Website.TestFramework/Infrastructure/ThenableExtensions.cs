﻿namespace ZGB.Website.TestFramework.Infrastructure;

// Based upon https://stackoverflow.com/a/55202519
public static class ThenableExtensions
{
    public static async Task<T2> Then<T1, T2>(this T1 first, Func<T1, Task<T2>> second)
    {
        return await second(first);
    }

    public static async Task<T2> Then<T1, T2>(this Task<T1> first, Func<T1, Task<T2>> second)
    {
        return await second(await first);
    }

    public static async Task<T2> Then<T1, T2>(this Task<T1> first, Func<T1, T2> second)
    {
        return second(await first);
    }

    public static Task<T2> Then<T1, T2>(this T1 first, Func<T1, T2> second)
    {
        return Task.FromResult(second(first));
    }

    public static async Task<T1> Assert<T1>(this Task<T1> first, Action<T1> second)
    {
        var result = await first;
        second(result);
        return result;
    }

    public static Task<T1> Assert<T1>(this T1 first, Action<T1> second)
    {
        var result = first;
        second(result);
        return Task.FromResult(result);
    }

    public static async Task<T1> Assert<T1>(this T1 first, Func<T1, Task> second)
    {
        var result = first;
        await second(result);
        return result;
    }

    public static async Task<T1> Assert<T1>(this Task<T1> first, Func<T1, Task> second)
    {
        var result = await first;
        await second(result);
        return result;
    }
}
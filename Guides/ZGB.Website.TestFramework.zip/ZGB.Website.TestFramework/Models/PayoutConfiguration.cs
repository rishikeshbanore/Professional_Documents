﻿namespace ZGB.Website.TestFramework.Models;

public class PayoutConfiguration
{
    public DateTime? pensionPayoutPcsDate {  get; set; }
    public DateTime? pensionPayoutABehaelter { get; set; }
    public DateTime? amsPayoutPcs { get; set; }
    public DateTime? amsPayoutABehaelter { get; set; }
}
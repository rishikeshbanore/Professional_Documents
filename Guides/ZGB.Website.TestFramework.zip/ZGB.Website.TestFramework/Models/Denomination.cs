﻿namespace ZGB.Website.TestFramework.Models;

public class Denomination
{
    public int? G500 { get; set; }
    public int? G200 { get; set; }
    public int? G100 { get; set; }
    public int? G50 { get; set; }
    public int? G20 { get; set; }
    public int? G10 { get; set; }
    public int? G5 { get; set; }
    public int? G2 { get; set; }
    public int? G1 { get; set; }
    public int? G050 { get; set; }
    public int? G020 { get; set; }
    public int? G010 { get; set; }
    public int? G005 { get; set; }
    public int? G002 { get; set; }
    public int? G001 { get; set; }

    public long Sum => (long)((G500.GetValueOrDefault() * 500) +
                              (G200.GetValueOrDefault() * 200) +
                              (G100.GetValueOrDefault() * 100) +
                              (G50.GetValueOrDefault() * 50) +
                              (G20.GetValueOrDefault() * 20) +
                              (G10.GetValueOrDefault() * 10) +
                              (G5.GetValueOrDefault() * 5) +
                              (G2.GetValueOrDefault() * 2) +
                              (G1.GetValueOrDefault() * 1) +
                              (G050.GetValueOrDefault() * 0.5) +
                              (G020.GetValueOrDefault() * 0.2) +
                              (G010.GetValueOrDefault() * 0.1) +
                              (G005.GetValueOrDefault() * 0.05) +
                              (G002.GetValueOrDefault() * 0.02) +
                              (G001.GetValueOrDefault() * 0.01));

    public static Denomination Create()
    {
        return new Denomination
        {
            G500 = 1000,
            G200 = 2000,
            G100 = 3000,
            G50 = 4000,
            G20 = 5000,
            G10 = 6000,
            G5 = 7000,
            G2 = 1,
            G1 = 2,
            G050 = 3,
            G020 = 4,
            G010 = 5,
            G005 = 6,
            G002 = 7,
            G001 = 8
        };
    }
}
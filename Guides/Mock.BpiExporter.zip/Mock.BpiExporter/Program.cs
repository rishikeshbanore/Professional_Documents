using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Hosting;
using Mock.BpiExporter;
using WireMock.Logging;
using WireMock.Server;
using WireMock.Settings;

var builder = Host.CreateApplicationBuilder(args);

builder.Services.AddWindowsService();


var host = builder.Build();

var url = builder.Configuration.GetValue<string>("Url")!;
var serviceEndpointPath = builder.Configuration.GetValue<string>("ServiceEndpointPath")!;

var server = WireMockServer.Start(new WireMockServerSettings
{
    Urls = [url],
    StartAdminInterface = true,
    ReadStaticMappings = true,
    Logger = new WireMockConsoleLogger(),
});

server.ConfigureMockEndpoint(serviceEndpointPath);

try
{
    await host.RunAsync();
}
finally
{
    host.Dispose();
}
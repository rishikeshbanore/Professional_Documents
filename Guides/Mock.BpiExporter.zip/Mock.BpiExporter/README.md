# Mock.BpiExporter

This Service mocks the CDAEvtSvc for testing purposes with [WireMock.Net](https://github.com/wiremock/WireMock.Net).
This Service is manually deployed to the BAA DEV and TEST environments.

## Deployment

0. exec `sc create PostAG.BAA.Mock.BpiExporter start= auto obj= "NT AUTHORITY\Network Service" password= "" binpath="E:\Service\BAA\Mock.BpiExporter\Mock.BpiExporter.exe"`
1. Copy over the new dll's.
2. start the service.

using BAA.ShipmentService.Application.Common;
using BpiSvc;
using WireMock.RequestBuilders;
using WireMock.ResponseBuilders;
using WireMock.Server;

namespace Mock.BpiExporter;

public static class WireMockConfiguration
{
    private const int SucceedStatusCode = 200;

    public static void ConfigureMockEndpoint(this WireMockServer server,string serviceEndpointPath)
    {
        var addEventResponse = SerializationHelper.SerializeToSoapResponse(new addEventResponse { Status = 0 });
        server.Given(
            Request.Create()
                .WithPath(serviceEndpointPath)
                .UsingPost()
                .WithBody("*")
        ).RespondWith(
            Response.Create()
                .WithStatusCode(SucceedStatusCode)
                .WithHeader("Content-Type", "text/xml")
                .WithBody(addEventResponse)
        );

    }
}